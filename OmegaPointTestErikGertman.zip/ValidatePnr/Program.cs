﻿using System;

namespace ValidatePnr
{
    class Program
    {


        public static void Main(string[] args)
        {
            string persNr = Console.ReadLine(); // Låter användaren mata in sitt personnummer
            persNr = persNr.Replace("-", ""); // Ersätter alla "-" med ingenting
            string sistaSiffran = ""; // Sista siffran sätts initialt till ingenting

            if (persNr.Length == 12) // Om användaren matar in 12 siffror
            {

                sistaSiffran = persNr.Substring(persNr.Length - 1); // Tar ut sista siffran i pnr
                persNr = persNr.Substring(2, 9); // Tar endast med nummer med index plats 2 till 9

            }
            else if (persNr.Length == 10) // Omm användaren matar in 10 siffror
            {

                sistaSiffran = persNr.Substring(persNr.Length - 1); // Tar ut sista siffran i pnr
                persNr = persNr.Substring(0, 9); // Tar endast med nummer med index plats 0 till 9

            }
            else
            {
                Console.WriteLine("Ange personnummer med 10 eller 12 siffror"); // Felmeddelande ifall man skriver in felaktigt format på pnr
            }
            int parsedSistaSiffran = int.Parse(sistaSiffran); // Gör om sista siffran i pnr till en int
            Console.WriteLine(persNr); // Skriver ut personnumret
            Console.WriteLine(sistaSiffran); // Skriver ut sista siffran i pnr
            Console.WriteLine(validatePnr(persNr, parsedSistaSiffran)); // kallar på metoden
           // Console.WriteLine(parsedSistaSiffran); // Kontroll ifall sista siffran i int stämmer



            static bool validatePnr(string input, int parsedSistaSiffran)
            {
                
                int[] pnrInt = new int[input.Length]; //Convertera input to int

                for (int i = 0; i < input.Length; i++)
                {
                    pnrInt[i] = (int)(input[i] - '0');
                }


                for (int i = pnrInt.Length - 1; i >= 0; i = i - 2) // Loopar varannat värde, börjar längst bak
                {
                    int tempValue = pnrInt[i]; // Sparar ett int som ett tillfälligt värde
                    tempValue = tempValue * 2; // multiplicerar varannat tillfälligt värde med 2
                    if (tempValue > 9) 
                    {
                        tempValue = tempValue % 10 + 1; // Om ett värde är högre än 9, delar det på 10 och lägger till 1 på kvarvarande siffra
                    }
                    pnrInt[i] = tempValue;
                }

                int total = 0; // Sätter initiallt total som 0
                for (int i = 0; i < pnrInt.Length; i++)
                {
                    total += pnrInt[i]; // Loopar igenom arrayen och plussar ihop våra siffror
                }


                if ((10 - (total % 10)) % 10 == parsedSistaSiffran) // om man tar in summan i Luhns formel = med sista siffran i pnrnumret = true
                {
                    return true;
                }

                //if (total % 10 == 0) // Annan lösning att om summan av talen är delbart med 10, ska den visa false
                //{
                //    return fase;
                //}

                // return true; // Annars true;


                return false;
            }




        }
    }


}

